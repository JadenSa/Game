﻿Imports System.Reflection.Emit

Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
    End Sub
    ' To move
    Private Sub Form4_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form4_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to Interact
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox4.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox5.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox6.Bounds) Or
            Player.Bounds.IntersectsWith(Label9.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label1.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Form3.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Form3.Show()
            Form3.Focus()
            Me.Hide()

        End If
    End Sub
    ' To exit
    Private Sub Form4_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class