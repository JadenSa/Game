﻿Public Class Form8
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
    End Sub
    ' To Move
    Private Sub Form7_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To Move
    Private Sub Form7_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to interact
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(Label2.Bounds) Or
                Player.Bounds.IntersectsWith(Label3.Bounds) Or
                Player.Bounds.IntersectsWith(Label4.Bounds) Or
                Player.Bounds.IntersectsWith(Label5.Bounds) Or
                Player.Bounds.IntersectsWith(Label6.Bounds) Or
                Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
                Player.Bounds.IntersectsWith(PictureBox4.Bounds) Or
                Player.Bounds.IntersectsWith(PictureBox5.Bounds) Or
                Player.Bounds.IntersectsWith(PictureBox6.Bounds) Or
                Player.Bounds.IntersectsWith(PictureBox7.Bounds) Or
                Player.Bounds.IntersectsWith(PictureBox8.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label1.Bounds) Or
            Player.Bounds.IntersectsWith(Label11.Bounds) Or
            Player.Bounds.IntersectsWith(Label12.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form7.Show()
            Form7.Focus()
            Form7.Timer1.Enabled = True
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(PictureBox2.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Label20.Visible = True
        End If
    End Sub
    ' Label to click to progress
    Private Sub Label20_Click(sender As Object, e As EventArgs) Handles Label20.Click
        Label20.Visible = False
        Label22.Visible = True
    End Sub
    ' Label to click to progress
    Private Sub Label22_Click(sender As Object, e As EventArgs) Handles Label22.Click
        Label22.Visible = False
        Label23.Visible = True
    End Sub
    ' Label to click to progress
    Private Sub Label23_Click(sender As Object, e As EventArgs) Handles Label23.Click
        Label23.Visible = False
        Label24.Visible = True
    End Sub
    ' Label to click to progress
    Private Sub Label24_Click(sender As Object, e As EventArgs) Handles Label24.Click
        Label24.Visible = False
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        count = True
    End Sub
    ' To exit
    Private Sub Form8_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class