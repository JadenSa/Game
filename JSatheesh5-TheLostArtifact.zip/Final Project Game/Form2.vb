﻿Imports System.Reflection.Emit

Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
        Label5.Visible = True
        Label6.Visible = True
    End Sub
    ' To exit
    Private Sub Form2_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
    ' To move
    Private Sub Form2_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To Move
    Private Sub Form2_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Timer for label/objective
    Private ReadOnly Total As New TimeSpan(0, 0, 20)
    Private ReadOnly Start As TimeSpan = TimeSpan.FromMilliseconds(Environment.TickCount)
    ' Borders to interact
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
            Player.Bounds.IntersectsWith(Label1.Bounds) Or
            Player.Bounds.IntersectsWith(Label2.Bounds) Or
            Player.Bounds.IntersectsWith(Label3.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox3.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label4.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form3.Timer1.Enabled = True
            Form3.Show()
            Form3.Focus()
            Me.Hide()
        End If

        Dim Now = TimeSpan.FromMilliseconds(Environment.TickCount)
        Dim Passed = Now - Start
        Dim Remaining = Total - Passed

        If Remaining.Seconds <= 0 Then
            Label5.Visible = False
            Label6.Visible = False
        End If
    End Sub
End Class