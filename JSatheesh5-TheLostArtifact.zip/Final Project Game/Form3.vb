﻿Imports System.Reflection.Emit

Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
        Brownpack = False
    End Sub
    ' To Move
    Private Sub Form3_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To Move
    Private Sub Form3_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to interact
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox4.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox6.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox7.Bounds) Or
            Player.Bounds.IntersectsWith(Label1.Bounds) Or
            Player.Bounds.IntersectsWith(Label5.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(PictureBox2.Bounds) Then
            Label2.Visible = True
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        Else
            Label2.Visible = False
        End If
        If Player.Bounds.IntersectsWith(Label3.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Form2.Show()
            Form2.Focus()
            Form2.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Label4.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Form4.Show()
            Form4.Focus()
            Form4.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Label6.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Form6.Show()
            Form6.Focus()
            Form6.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(PictureBox5.Bounds) Then
            Label7.Visible = True
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        Else
            Label7.Visible = False
        End If
        If Player.Bounds.IntersectsWith(Backpack.Bounds) And Backpack.Visible = True Then
            Brownpack = True
            Backpack.Visible = False
        End If
    End Sub
    ' To exit
    Private Sub Form3_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class