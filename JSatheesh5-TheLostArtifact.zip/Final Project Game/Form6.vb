﻿Imports System.Reflection.Emit

Public Class Form6
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        count = 0
        dx = 0
        dy = 0
        Brownpack = False
    End Sub
    ' To move
    Private Sub Form6_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form6_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Timer for Label
    Private ReadOnly Total As New TimeSpan(0, 0, 20)
    Private ReadOnly Start As TimeSpan = TimeSpan.FromMilliseconds(Environment.TickCount)
    ' Borders to interact
    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox4.Bounds) Or
            Player.Bounds.IntersectsWith(Label7.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox5.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox6.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label8.Bounds) Then
            Form7.Show()
            Form7.Focus()
            Form7.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Label1.Bounds) Then
            Form3.Show()
            Form3.Focus()
            Form3.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Me.Hide()
        End If
        If count = True Then
            If Player.Bounds.IntersectsWith(Label4.Bounds) Then
                Form9.Show()
                Form9.Focus()
                Form9.Timer1.Enabled = True
                Me.Timer1.Enabled = False
                Me.Hide()
            End If
        End If
        If Player.Bounds.IntersectsWith(Backpack.Bounds) And Backpack.Visible = True Then
            Brownpack = True
            Backpack.Visible = False
        End If
        If count = False Then
            If Player.Bounds.IntersectsWith(Label4.Bounds) Then
                Player.Left = Player.Left - dx
                Player.Top = Player.Top - dy
                Label3.Visible = True
            Else
                Label3.Visible = False
            End If
        End If
        Dim Now = TimeSpan.FromMilliseconds(Environment.TickCount)
        Dim Passed = Now - Start
        Dim Remaining = Total - Passed


        If Remaining.Seconds <= 0 Then
            'tmr.Stop()
            Object2.Visible = False
            ObjectL2.Visible = False
        End If

    End Sub
    ' To exit
    Private Sub Form6_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class