﻿Public Class Form12
    Private Sub Form12_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
        RelicNum1 = False
    End Sub
    ' To move
    Private Sub Form12_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form12_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to intersect
    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox4.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox5.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox6.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox7.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox8.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox9.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox10.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox11.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox12.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox13.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox16.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox17.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox18.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox19.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox20.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox21.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label6.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form11.Show()
            Form11.Focus()
            Form11.Timer1.Enabled = True
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Label5.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            RelicNum1 = True
            Relic1.Visible = False
        End If
    End Sub
    ' To exit
    Private Sub Form12_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub

End Class