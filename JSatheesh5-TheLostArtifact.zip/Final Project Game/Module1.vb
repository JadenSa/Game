﻿Module Module1
    Public dx, dy As Integer
    Public Pfront As Image = My.Resources.Sprite1
    Public Pleft As Image = My.Resources.Sprite2
    Public Pright As Image = My.Resources.Sprite3
    Public Pback As Image = My.Resources.Sprite4
    Public count As Boolean
    Public Efront As Image = My.Resources.Mummy1
    Public Eleft As Image = My.Resources.Mummy2
    Public Eright As Image = My.Resources.Mummy3
    Public Eback As Image = My.Resources.Mummy4
    Public Brownpack As Boolean
    Public RelicNum1 As Integer
    Public RelicNum2 As Integer
End Module
