﻿Public Class Form5
    ' Button to click to progress
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Focus()
        Form1.Label1.Visible = False
    End Sub
    ' To exit
    Private Sub Form5_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class