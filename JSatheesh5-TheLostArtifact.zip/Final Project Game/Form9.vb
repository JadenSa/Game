﻿Imports System.Reflection.Emit

Public Class Form9
    Dim Border As Boolean
    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
        Border = False
        BrownPack = False
    End Sub
    ' To move
    Private Sub Form9_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form9_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borers to interact with
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(Label2.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox3.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            'Player.Bounds.IntersectsWith(PictureBox6.Bounds) Or
            'Player.Bounds.IntersectsWith(PictureBox7.Bounds) Or
        End If
        If Border = True Then
            If Player.Bounds.IntersectsWith(Label4.Bounds) Then

            End If
        Else
            If Player.Bounds.IntersectsWith(Label4.Bounds) Then
                Player.Left = Player.Left - dx
                Player.Top = Player.Top - dy
                Label5.Visible = True
            End If
        End If
        If Player.Bounds.IntersectsWith(PictureBox2.Bounds) Then
            Label5.Visible = False
            Label6.Visible = True
        End If

        If Player.Bounds.IntersectsWith(Label7.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Form6.Show()
            Form6.Focus()
            Form6.Timer1.Enabled = True
            Me.Timer1.Enabled = False
        End If
        If Player.Bounds.IntersectsWith(Label3.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Form10.Show()
            Form10.Focus()
            Form10.Timer1.Enabled = True
            Me.Timer1.Enabled = False
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Backpack.Bounds) And Backpack.Visible = True Then
            Brownpack = True
            Backpack.Visible = False
        End If
    End Sub
    ' Text to click
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Label6.Visible = False
        Border = True
    End Sub
    ' To exit
    Private Sub Form9_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class