﻿Public Class Form14
    Private Sub Form14_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
        RelicNum1 = False
    End Sub
    ' To move
    Private Sub Form14_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form14_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to intersect
    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(Label1.Bounds) Or
           Player.Bounds.IntersectsWith(Label2.Bounds) Or
           Player.Bounds.IntersectsWith(Label3.Bounds) Or
           Player.Bounds.IntersectsWith(Label4.Bounds) Or
            Player.Bounds.IntersectsWith(Label5.Bounds) Or
           Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
           Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
           Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
           Player.Bounds.IntersectsWith(PictureBox4.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label6.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form10.Show()
            Form10.Focus()
            Form10.Timer1.Enabled = True
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Sacaphogus.Bounds) Then
            Label8.Visible = True
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            If Player.Bounds.IntersectsWith(Label6.Bounds) Then
                Player.Left = Player.Left - dx
                Player.Top = Player.Top - dy
            End If
        End If
    End Sub
    ' Text to progress
    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        Label8.Visible = False
        Label7.Visible = True
    End Sub
    ' Text to progress
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Label7.Visible = False
        Label9.Visible = True
    End Sub
    ' Text to progress
    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        Label9.Visible = False
        Label10.Visible = True
    End Sub
    ' Text to progress to end
    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Label10.Visible = False
        Player.Left = Player.Left - dx
        Player.Top = Player.Top - dy
        Me.Timer1.Enabled = False
        Form15.Show()
        Form15.Focus()
        Me.Hide()
    End Sub
    Private Sub Form14_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class