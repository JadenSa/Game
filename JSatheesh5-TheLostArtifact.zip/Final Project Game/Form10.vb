﻿Imports System.Reflection.Emit

Public Class Form10
    Private Sub Form10_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        count = 0
        dx = 0
        dy = 0
        Label10.Visible = False
        Object3.Visible = True
        ObjectL3.Visible = True
    End Sub
    ' To move
    Private Sub Form10_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To Move
    Private Sub Form10_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Timer for label/objective
    Private ReadOnly Total As New TimeSpan(0, 0, 20)
    Private ReadOnly Start As TimeSpan = TimeSpan.FromMilliseconds(Environment.TickCount)
    ' Borders to interact
    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(Label1.Bounds) Or
        Player.Bounds.IntersectsWith(Label2.Bounds) Or
        Player.Bounds.IntersectsWith(Label3.Bounds) Or
        Player.Bounds.IntersectsWith(Label4.Bounds) Or
        Player.Bounds.IntersectsWith(Label5.Bounds) Or
        Player.Bounds.IntersectsWith(Label6.Bounds) Or
        Player.Bounds.IntersectsWith(Label7.Bounds) Or
        Player.Bounds.IntersectsWith(Label8.Bounds) Or
        Player.Bounds.IntersectsWith(Label9.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox6.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If RelicNum1 = False And RelicNum2 = False And Player.Bounds.IntersectsWith(Label11.Bounds) Then
            Label10.Visible = True
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If RelicNum1 = True And RelicNum2 = True And Player.Bounds.IntersectsWith(Label11.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Label13.Visible = True
        End If
        If Player.Bounds.IntersectsWith(PictureBox5.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form11.Show()
            Form11.Focus()
            Form11.Timer1.Enabled = True
            Me.Hide()
        End If
        Dim Now = TimeSpan.FromMilliseconds(Environment.TickCount)
        Dim Passed = Now - Start
        Dim Remaining = Total - Passed
        If Player.Bounds.IntersectsWith(Label12.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form13.Show()
            Form13.Focus()
            Form13.Timer1.Enabled = True
            Me.Hide()
        End If

        If Remaining.Seconds <= 0 Then
            Object3.Visible = False
            ObjectL3.Visible = False
        End If
    End Sub
    ' To exit
    Private Sub Form10_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
    ' text to transition
    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click
        Label13.Visible = False
        Player.Left = Player.Left - dx
        Player.Top = Player.Top - dy
        Me.Timer1.Enabled = False
        Form14.Show()
        Form14.Focus()
        Form14.Timer1.Enabled = True
        Me.Hide()
    End Sub
    ' Text to progress
    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Label10.Visible = False
    End Sub
End Class