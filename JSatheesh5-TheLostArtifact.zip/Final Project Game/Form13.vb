﻿Imports System.Reflection.Emit
Imports System.Threading
Public Class Form13
    Dim RandLoc As Integer
    Private Sub Form13_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dx = 0
        dy = 0
        RelicNum2 = False
        Brownpack = False
    End Sub
    ' To moev
    Private Sub Form13_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form13_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to interact with
    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
        Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
        Player.Bounds.IntersectsWith(Label10.Bounds) Or
        Player.Bounds.IntersectsWith(Label11.Bounds) Or
        Player.Bounds.IntersectsWith(Label12.Bounds) Or
        Player.Bounds.IntersectsWith(Label13.Bounds) Or
        Player.Bounds.IntersectsWith(Label14.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Label1.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form10.Show()
            Form10.Focus()
            Form10.Timer1.Enabled = True
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Enemy1.Bounds) Then
            Timer1.Enabled = False
            Timer2.Enabled = False
            Timer3.Enabled = False
            Timer4.Enabled = False
            Timer5.Enabled = False
            Death1.Visible = True
            DeathL1.Visible = True
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
        End If
        If Player.Bounds.IntersectsWith(Collector.Bounds) And Brownpack = False Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Label2.Visible = True
        ElseIf Player.Bounds.IntersectsWith(Collector.Bounds) And Brownpack = True Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Label8.Visible = True
        End If
    End Sub
    ' Enemy Timer to move
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If Enemy1.Top < 380 Then
            Enemy1.Top = Enemy1.Top + 6
        ElseIf Enemy1.Top >= 380 Then
            Timer2.Enabled = False
            Timer4.Enabled = True
        End If
        Enemy1.Image = Efront
    End Sub
    ' Enemy Timer to move
    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If Enemy1.Left < 1095 Then
            Enemy1.Left = Enemy1.Left + 6
        ElseIf Enemy1.Left >= 1095 Then
            Timer2.Enabled = True
            Timer3.Enabled = False
        End If
        Enemy1.Image = Eleft
    End Sub
    ' Enemy Timer to move
    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        If Enemy1.Left > 12 Then
            Enemy1.Left = Enemy1.Left - 6
        ElseIf Enemy1.Left <= 12 Then
            Timer5.Enabled = True
            Timer4.Enabled = False
        End If
        Enemy1.Image = Eright
    End Sub
    ' Enemy Timer to move
    Private Sub Timer5_Tick(sender As Object, e As EventArgs) Handles Timer5.Tick
        If Enemy1.Top > 284 Then
            Enemy1.Top = Enemy1.Top - 6
        ElseIf Enemy1.Top <= 284 Then
            Timer5.Enabled = False
            Timer3.Enabled = True
        End If
        Enemy1.Image = Eback
    End Sub
    ' Text progression
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Label2.Visible = False
        Label3.Visible = True
    End Sub
    ' Text progression
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Label3.Visible = False
        Label4.Visible = True
    End Sub
    ' Text progression
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Label4.Visible = False
        Label5.Visible = True
    End Sub
    ' Text progression
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Label5.Visible = False
        Label6.Visible = True
    End Sub
    ' Text progression
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Label6.Visible = False
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        RandLoc = 1
        If RandLoc = 1 Then
            Form11.Backpack.Visible = True
        End If
    End Sub
    ' To Exit
    Private Sub Form13_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
    ' Text to click to progress
    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        Label8.Visible = False
        RelicNum2 = True
    End Sub
End Class