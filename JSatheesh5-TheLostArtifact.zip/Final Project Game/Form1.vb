﻿' Jaden Satheesh
' The Lost Artifact
' 5/31/2023

Public Class Form1
    Dim count As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        count = 0
    End Sub
    ' Start Game
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form2.Show()
        Form2.Focus()
    End Sub
    ' Gear Icon shows options to make game modified
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        count = count + 1
        If count Mod 2 = 0 Then
            GroupBox1.Visible = True
            GroupBox1.Enabled = True
        Else
            GroupBox1.Visible = False
            GroupBox1.Enabled = False
        End If
    End Sub
    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        CheckBox3.Checked = True
    End Sub
    ' Exit Game
    Private Sub Form1_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
    ' Manual
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Form5.Show()
        Form5.Focus()
        Button1.Enabled = True
    End Sub
End Class
