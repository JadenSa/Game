﻿Public Class Form15

    Private Sub Form15_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class