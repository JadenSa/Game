﻿Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar

Public Class Form7
    Dim count As Integer
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        count = 0
        dx = 0
        dy = 0
    End Sub
    ' To move
    Private Sub Form7_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 5
            Player.Image = Pright
        ElseIf e.KeyCode = Keys.Left Then
            dx = -5
            Player.Image = Pleft
        ElseIf e.KeyCode = Keys.Up Then
            dy = -5
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 5
            Player.Image = Pfront
        End If
    End Sub
    ' To move
    Private Sub Form7_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Right Then
            Player.Image = Pright
            dx = 0
        ElseIf e.KeyCode = Keys.Left Then
            Player.Image = Pleft
            dx = 0
        ElseIf e.KeyCode = Keys.Up Then
            dy = 0
            Player.Image = Pback
        ElseIf e.KeyCode = Keys.Down Then
            dy = 0
            Player.Image = Pfront
        End If
    End Sub
    ' Borders to interact
    Public Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left = Player.Left + dx
        Player.Top = Player.Top + dy
        If Player.Bounds.IntersectsWith(PictureBox1.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox2.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox3.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox4.Bounds) Or
            Player.Bounds.IntersectsWith(PictureBox5.Bounds) Or
            Player.Bounds.IntersectsWith(Label2.Bounds) Or
            Player.Bounds.IntersectsWith(Label3.Bounds) Or
            Player.Bounds.IntersectsWith(Label4.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            'Player.Bounds.IntersectsWith(PictureBox6.Bounds) Or
            'Player.Bounds.IntersectsWith(PictureBox7.Bounds) Or
        End If
        If Player.Bounds.IntersectsWith(PictureBox2.Bounds) Then
            Label2.Visible = True
        Else
            Label2.Visible = False
        End If
        If Player.Bounds.IntersectsWith(Label1.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form6.Show()
            Form6.Focus()
            Form6.Timer1.Enabled = True
            Me.Hide()
        End If
        If Player.Bounds.IntersectsWith(Label5.Bounds) Then
            Player.Left = Player.Left - dx
            Player.Top = Player.Top - dy
            Me.Timer1.Enabled = False
            Form8.Show()
            Form8.Focus()
            Form8.Timer1.Enabled = True
            Me.Hide()
        End If
    End Sub
    ' To Exit
    Private Sub Form7_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Application.Exit()
    End Sub
End Class